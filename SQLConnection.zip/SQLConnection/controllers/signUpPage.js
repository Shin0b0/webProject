exports.signUpPage = (req, res) => {
    res.send("SignUp PAGE");
  };