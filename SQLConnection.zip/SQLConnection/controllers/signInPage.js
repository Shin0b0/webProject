const db = require("../models/index.model");
const user = db.user;
const bodyParser = require("body-parser");

// --------------------------------------

exports.Add = async (req, res) => {
  // Validate request
  if (!req.body.uname) {
    res.status(400).send({
      message: "Content can not be empty!",
    });
    return;
  }

  const { uname, email, password } = req.body;

  user
    .create({
      uname,
      email,
      password,
    })
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the cart_items.",
      });
    });
  };

// View Login
exports.Views = (req, res) => {
  user
    .findAll()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving user",
      });
    });
};

exports.Updates = (req, res) => {
  const id = req.params.id;

  user
    .update(req.body, {
      where: { id: "41" },
    })
    .then((num) => {
      if (num == 1) {
        res.send({
          message: "order_items was updated successfully.",
        });
      } else {
        res.send({
          message: `Cannot update order_items with id=${id}. Maybe order_items was not found or req.body is empty!`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating order_items with id=" + id,
      });
    });
};

// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
  user
    .destroy({
      where: {},
      truncate: false,
    })
    .then((nums) => {
      res.send({ message: `${nums} All users were deleted successfully!` });
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while removing all users.",
      });
    });
};

// Find a single Tutorial with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  user
    .findByPk(id)
    .then((data) => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find cart_items with id=${id}.`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error retrieving cart_items with id=" + id,
      });
    });
};
