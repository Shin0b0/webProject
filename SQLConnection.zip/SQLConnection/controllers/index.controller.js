exports.home = function (req, res) {
  res.send("HOME PAGE");
};


