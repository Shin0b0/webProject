const express = require("express");
const router = express.Router();
const bodyParser = require('body-parser');

//import functions
const { home } = require("../controllers/index.controller");
const { signUpPage } = require("../controllers/signUpPage");
const { signInPage, Views, Add, Updates, deleteAll, findOne } = require("../controllers/signInPage");

// Routes
router.get("/home", (req, res) => home(req, res));
router.get("/signUp", (req, res) => signUpPage(res, req));
router.get("/signIn/View",Views);
router.get("/signIn/find/:id",findOne);
router.post("/signIn/Add",Add);
router.put("/signIn/:id", Updates);
router.delete("/signIn/Delete", deleteAll);
router.get("*",(req,res)=>{
    res.sendFile(__dirname+"/error.html")
})

module.exports = router;
